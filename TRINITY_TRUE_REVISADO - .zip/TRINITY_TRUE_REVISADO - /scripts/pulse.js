function goToSplash() {
  window.location.href = "splash.html";
}
